<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('index',[
	'as'=>'trang-chu',
	'uses'=>'Pagecontroller@getIndex'
]);

Route::get('loai-san-pham/{type}',[
	'as'=>'loaisanpham',
	'uses'=>'Pagecontroller@getLoaiSp'
]);

Route::get('chi-tiet-san-pham/{id}',[
	'as'=>'chitietsanpham',
	'uses'=>'Pagecontroller@getChitiet'
]);

Route::get('lien-he',[
	'as'=>'lienhe',
	'uses'=>'Pagecontroller@getLienHe'
]);

Route::get('gioi-thieu',[
	'as'=>'gioithieu',
	'uses'=>'Pagecontroller@getGioiThieu'
]);

Route::get('add-to-cart/{id}',[
	'as'=>'themgioihang',
	'uses'=>'Pagecontroller@getAddtoCart'
]);

Route::get('del-cart/{id}',[
	'as'=>'xoagioihang',
	'uses'=>'Pagecontroller@getDelItemCart'
]);

Route::get('dat-hang',[
	'as'=>'dathang',
	'uses'=>'Pagecontroller@getCheckout'
]);

Route::post('dat-hang',[
	'as'=>'dathang',
	'uses'=>'Pagecontroller@getpostCheckout'
]);


Route::get('dang-nhap',[
	'as'=>'login',
	'uses'=>'Pagecontroller@getLogin'
]);


Route::post('dang-nhap',[
	'as'=>'login',
	'uses'=>'Pagecontroller@postLogin'
]);




Route::get('dang-ki',[
	'as'=>'signin',
	'uses'=>'Pagecontroller@getSignin'
]);


Route::post('dang-ki',[
	'as'=>'signin',
	'uses'=>'Pagecontroller@postSignin'
]);


Route::get('dang-xuat',[
	'as'=>'logout',
	'uses'=>'Pagecontroller@getLogout'
]);

Route::get('search',[
	'as'=>'search',
	'uses'=>'Pagecontroller@getSearch'
]);